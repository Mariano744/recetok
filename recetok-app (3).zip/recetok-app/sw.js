const VERSION = "recetok-v1";
const SHELL = ["/", "/index.html", "/standalone.js", "/manifest.webmanifest", "/icons/icon-192.png", "/icons/icon-512.png", "/icons/apple-touch-icon.png", "/icons/favicon.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const req = e.request, url = new URL(req.url);
  if(req.method !== "GET" || url.pathname.startsWith("/api/")) return;           // la IA siempre va a la red
  if(req.mode === "navigate"){                                                    // página: red primero, copia si no hay conexión
    e.respondWith(fetch(req).then(r => { const cp = r.clone(); caches.open(VERSION).then(c => c.put("/index.html", cp)); return r; })
      .catch(() => caches.match("/index.html")));
    return;
  }
  e.respondWith(caches.match(req).then(hit => {                                   // resto (íconos, fuentes): caché y se actualiza
    const net = fetch(req).then(r => { if(r.ok || r.type === "opaque"){ const cp = r.clone(); caches.open(VERSION).then(c => c.put(req, cp)); } return r; }).catch(() => hit);
    return hit || net;
  }));
});
